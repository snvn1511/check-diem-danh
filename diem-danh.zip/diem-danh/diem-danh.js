// link sửa điểm danh ndance/1030703?action=edit&group_id=53124
btnCheck = document.querySelector("#btn_check");
btnCount = document.querySelector("#btn_count");
var current_url = "";
async function getCurrentTab() {
    let queryOptions = { active: true, currentWindow: true };
    let [tab] = await chrome.tabs.query(queryOptions);
    return tab;
  }

  getCurrentTab().then(function (data) {
  
    // console.log(data.url);
    current_url = data.url;

    if (data.url.indexOf('gv.poly.edu.vn/teacher/attendance/') < 0 &&
    data.url.indexOf('gv.poly.edu.vn/teacher/my_class/view/') < 0) {
  
        btnCheck.setAttribute('disabled', 'disabled');
        btnCheck.setAttribute('disabled', 'disabled');
    }
    else {
      currentLinkClass = data.url;
      btnCheck.removeAttribute('disabled');

     

     }
  });
 

  btnCheck.addEventListener('click', async () => {

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // if(tab.url.indexOf('gv.poly.edu.vn/teacher/attendance/')<0  ){
    //     chrome.tabs.query({ currentWindow: true, active: true }, function (tab) {
    //     chrome.tabs.update(tab.id, { url: 'https://gv.poly.edu.vn/teacher/attendance/' });
    //     });
    //     return;
    // }

    chrome.scripting.executeScript({

        target: { tabId: tab.id },
        function: CheckDiemDanh,
    });

  
  });


  btnCount.addEventListener('click', async () => {
    if(current_url.indexOf('gv.poly.edu.vn/teacher/my_class/view/') < 0){
        alert("Hãy vào phần Lớp của tôi và bấm chọn Tên lớp trước khi thực hiện thao tác này");
        return;
    }

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.scripting.executeScript({

        target: { tabId: tab.id },
        function: ThongKe,
    });


  });





function CheckDiemDanh() {
    console.log("check diem danh");
    console.log(window.location.search);
    const queryString = window.location.search;
    console.log(queryString);
    const urlParams = new URLSearchParams(queryString);

    let group_id = urlParams.get('group_id') ; 

    if (group_id == null  ) {
        console.log("Cần vào trang sửa điểm danh mới thực hiện được");
        return;
    }
    console.log(group_id);

    // link bang diem danh
    // let link_bang_diem_danh = 'https://gv.poly.edu.vn/teacher/my_class/view/'+ group_id;
    let link_diem_danh = 'https://gv.poly.edu.vn/teacher/group/get_attendance_by_group_id/'+group_id+'?campus_code=ph';
    fetch(link_diem_danh)
        .then(function (res) {
          return res.json();
        })
        .then(function (json_data) {
            // nội dung bảng điểm danh
            console.log(json_data.data);

             // console.log(str_html);
        //   let dom_content = new DOMParser().parseFromString(str_html, "text/html");

        //   console.dir(dom_content)
        //   let table_attendance = dom_content.querySelector('#attendance');
        //   if(table_attendance == null ){
        //     console.log("Không đúng trang");
        //   }
            
        // find TD:
        let list_tr = document.querySelectorAll('tr');

        console.log(list_tr);

        console.log(list_tr.length);

        let members = json_data.data.members;
        members.forEach((item)=>{
            console.log(item.absent + "--absent-" + item.user_code);
                           console.log(list_tr.length);

            for(i = 0; i< list_tr.length; i++){
                let tr = list_tr[i];

                let found = true;
                
                let td = tr.children[1];
                 if(td == null || td.innerText.trim().indexOf(item.user_code)<0){
                    found = false;
                }else{
                    found = true;
                }
                
                if(!found){
                    td = tr.children[2];
                    console.log("Child 2");
                    if(td == null || td.innerText.trim().indexOf(item.user_code)<0){
                        found = false;
                    }else{
                        found = true;
                    }

                    

                }
                if(!found) continue;   
                console.log(i + '==='+ found + '==>'+ td.innerText + '------' + item.user_code);
              

                
                 td.setAttribute("style",'backround:green');

                if(td.innerText.trim().indexOf(item.user_code)>=0){
                     console.log("append...");
                    let span = document.createElement("span");
                    if(item.absent>=3){
                        span.setAttribute("style","background:yellow; color:red");
                    }
                    span.innerHTML = "(" + item.absent + ")";

                    td.appendChild(span);
                    break;
                }
            }



            // let td = document.querySelector("td:contains('"+item.user_code+"')");
            
        });



        }
    );

}


 


function ThongKe() {
    console.log("Thống kê diem danh");
    console.log(window.location.search);
    const queryString = window.location.search;
    console.log(queryString);
    const urlParams = new URLSearchParams(queryString);

    let group_id = urlParams.get('group_id') ; 

    if (group_id == null  ) {
        console.log("Cần vào trang sửa điểm danh mới thực hiện được");
        return;
    }
    console.log(group_id);

    // link bang diem danh
    // let link_bang_diem_danh = 'https://gv.poly.edu.vn/teacher/my_class/view/'+ group_id;
    let link_diem_danh = 'https://gv.poly.edu.vn/teacher/group/get_attendance_by_group_id/'+group_id+'?campus_code=ph';
    fetch(link_diem_danh)
        .then(function (res) {
          return res.json();
        })
        .then(function (json_data) {
            // nội dung bảng điểm danh
            console.log(json_data.data);

             // console.log(str_html);
        //   let dom_content = new DOMParser().parseFromString(str_html, "text/html");

        //   console.dir(dom_content)
        //   let table_attendance = dom_content.querySelector('#attendance');
        //   if(table_attendance == null ){
        //     console.log("Không đúng trang");
        //   }
            
        // find TD:
        let list_tr = document.querySelectorAll('tr');

        console.log(list_tr);

        console.log(list_tr.length);

        let members = json_data.data.members;
        members.forEach((item)=>{
            console.log(item.absent + "--absent-" + item.user_code);
                           console.log(list_tr.length);

            for(i = 0; i< list_tr.length; i++){
                let tr = list_tr[i];

                let found = true;
                
                let td = tr.children[1];
                 if(td == null || td.innerText.trim().indexOf(item.user_code)<0){
                    found = false;
                }else{
                    found = true;
                }
                
                if(!found){
                    td = tr.children[2];
                    console.log("Child 2");
                    if(td == null || td.innerText.trim().indexOf(item.user_code)<0){
                        found = false;
                    }else{
                        found = true;
                    }

                    

                }
                if(!found) continue;   
                console.log(i + '==='+ found + '==>'+ td.innerText + '------' + item.user_code);
              

                
                 td.setAttribute("style",'backround:green');

                if(td.innerText.trim().indexOf(item.user_code)>=0){
                     console.log("append...");
                    let span = document.createElement("span");
                    if(item.absent>=3){
                        span.setAttribute("style","background:yellow; color:red");
                    }
                    span.innerHTML = "(" + item.absent + ")";

                    td.appendChild(span);
                    break;
                }
            }



            // let td = document.querySelector("td:contains('"+item.user_code+"')");
            
        });



        }
    );

}


  

