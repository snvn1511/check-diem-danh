let link_meet = document.querySelector('#link_meet');
let btnSave = document.querySelector('#btn_save');
let btnUpdate = document.querySelector('#btn_update');
let msg = document.querySelector('#msg');
let btCheck = /https:\/\/meet.google.com\/[a-zA-Z0-9]{3}\-[a-zA-Z0-9]{4}\-[a-zA-Z0-9]{3}/;
let currentMeet = document.querySelector('#currentMeet');
// console.log(bieu_thuc.test("https://meet.google.com/hzm-zzuy-bpi"));



chrome.tabs.query({ active: true, lastFocusedWindow: true }, tabs => {
    let url = tabs[0].url;
    // use `url` here inside the callback because it's asynchronous!

});

 chrome.storage.sync.get('url_meet', (data) => {
    currentMeet.innerHTML ="Link meet đã lưu:<br>" + data.url_meet;

 });


async function getCurrentTab() {
    let queryOptions = { active: true, currentWindow: true };
    let [tab] = await chrome.tabs.query(queryOptions);
    return tab;
}

getCurrentTab().then(function (data) {
    console.log(data.url);
    if (data.url.indexOf('https://gv.poly.edu.vn/admin') < 0)
       
        {
            btnUpdate.setAttribute('disabled', 'disabled');
            btnUpdate.innerHTML ="Nút bấm này chỉ có tác dụng ở trang https://gv.poly.edu.vn/admin";
            document.querySelector('#tip-update').style.display ='none';
        }
        else
        {
            btnUpdate.innerHTML ="Update link meet to gv.poly.edu.vn ";
            document.querySelector('#tip-update').style.display ='block';
        }
});

btnSave.disabled = (link_meet.value.length == 0);


function enableBtnSave(){
  // console.log(link_meet);
    // console.log('nhap noi dung');
    if (link_meet.value.trim().length > 5 && btCheck.test(link_meet.value.trim())) {
        btnSave.removeAttribute('disabled');
        msg.innerHTML='<span style="color:blue">OK, bấm nút Save để lưu lại link meet trên trình duyệt web này.</span>';
    }else{
        msg.innerHTML = '<span style="color:red">Hãy kiểm tra lại link meet, chưa đúng.</span>';
    }
}


link_meet.onkeyup = enableBtnSave;
link_meet.onchanged = enableBtnSave;


btnSave.addEventListener('click', () => {
    console.log(link_meet.value);
    if (link_meet.value.trim().length == 0) {
        alert('cần nhập link google meet');
        return;
    }
    url_meet = link_meet.value.trim();
    // ghi vào storage
    chrome.storage.sync.set({ url_meet });
    // đọc ra 
    msg.innerHTML = '<span style="color:blue">OK đã lưu.</span>';

    chrome.storage.sync.get('url_meet', (data) => {
        currentMeet.innerHTML ="Link meet đã lưu:<br>" + data.url_meet;
    
     });

})


btnUpdate.addEventListener('click', async () => {

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.storage.sync.set({ alert: '123' });

    chrome.scripting.executeScript({
        
        target: { tabId: tab.id },
        function: setUrlMeet,
    });
 


});

function setUrlMeet() {
    console.log("call setUrlMeet");
    
  




    chrome.storage.sync.get('url_meet', (data) => {
        console.log(data.url_meet);

         


    setTimeout(function (){
        let _input = document.querySelectorAll('input[name=link]');
        _input.forEach(function (el) {
            el.value = data.url_meet;
        })

        

        let _btn = document.querySelectorAll('td.add-link-study-online button');
        _btn.forEach(function (el) {
            el.click();
        })
         window.location.reload();

    }, 2000);

        

       
    });
}


